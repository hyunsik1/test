﻿예제 코드 실행 방법
-----------------------

웹 브라우저에서 index_initial.html 파일을 열어 recentRegistrationsService_01_tests.js를 실행한다.
다른 테스트를 전부 실행하려면 index.html 파일을 연다.
