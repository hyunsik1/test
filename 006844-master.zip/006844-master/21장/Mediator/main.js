﻿var Game = Game || {};

(function() {
  window.onload = function() {
    Game.mediator().startGame();
  };
}());