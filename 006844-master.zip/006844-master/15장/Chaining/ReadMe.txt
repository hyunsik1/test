﻿예제 코드 실행 방법
--------------------------

presenterEvaluation_nn.js를 테스트하려면 브라우저에서 index_nn 파일을 연다.
