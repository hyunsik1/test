﻿var Conference = Conference || {};
Conference.transportCompanyFactory = function() {
  'use strict';

  return {
    create: function create(transportDetails) {
      // transportDetails를 보고
      // 어떤 운송회사 모듈을 생성/반환해야 할지 결정한다
    }
  };
}