﻿예제 코드 실행 방법
-----------------------

attendeePage.js 원버전을 실행하려면 index.html 파일을 더블클릭해서 브라우저에 띄운다.
개선된 버전은 index_Improved.html 파일을 더블클릭한다.
