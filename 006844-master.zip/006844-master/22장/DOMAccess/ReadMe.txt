﻿예제 코드 실행 방법
--------------------------

JavaScript 및 HTML 혼합 예제는 inline.html 파일에 들어있다.


clickCoundDisplay 파일은 세 부분으로 구성되며, 버전별로 일련 번호 01, 02, 03이 붙어있다.

- clickCountDisplay_nn.js는 테스트 대상 코드다.
- 테스트 코드는 clickCountDisplay_nn_tests.js에 있다.
- index_nn.js는 재스민으로 테스트를 실행하기 위한 HTML 파일이다.

세 부분을 실행하려면 웹 브라우저에서 index_nn.html 파일을 그냥 열면 된다.
