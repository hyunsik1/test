﻿예제 코드 실행 방법
-----------------------

ContractRegistry_nn.js를 테스트하려면 브라우저에서 index_nn 파일을 연다.

최종본 ContractRegistry.js은 뒤에 숫자가 없으며, index.html 파일을 실행하면 ContractRegistry_tests.js 테스트할 수 있다.
