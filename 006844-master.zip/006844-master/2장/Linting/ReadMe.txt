﻿예제 코드 실행 방법
--------------------------

index.html는 Listing_01.js를 테스트 대상으로 하여, Listing_01_tests.js의 테스트 코드를 실행하게끔 작성되어 있다. 브라우저에서 index.html를 열어 테스트를 실행하면 된다.

Listing_02.js 대신 Listing_01.js를 가리키도록 index.html 파일을 수정하면 테스트는 성공할 것이다.
