﻿function createReservation(passenger, flight) {
  return {
    passengerInformation: passenger,
    flightInformation: flight
  };
}