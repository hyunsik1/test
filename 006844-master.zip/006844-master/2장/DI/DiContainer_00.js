﻿DiContainer = function() {
};

DiContainer.prototype.register = function(name,dependencies,func) {
  // 처음 버전이라 하는 일이 없다.
};