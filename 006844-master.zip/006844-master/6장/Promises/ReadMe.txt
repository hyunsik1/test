﻿예제 코드 실행 방법
-----------------------

checkInService_01_tests.js에서 checkInService_01.js와 테스트를 실행하려면 checkInService_01.html를 더블클릭한다.

checkInRecorder_01_tests.js에서 checkInRecorder_01.js와 테스트를 실행하려면 checkInRecorder_01.html를 더블클릭하거나, 브라우저에서 .html 파일을 연다.

checkInService.js와 checkInRecorder.js 최종본은 index.html를 더블클릭하여 실행한다.
